# Simplified Hierarchical Aperceptive Memory (HPA)
class HPAMemory:
    def __init__(self):
        self.short_term = []
        self.mid_term = []
        self.long_term = []

    def store(self, input_data):
        self.short_term.append(input_data)
        if len(self.short_term) > 10:
            self.mid_term.append(self.short_term.pop(0))
        if len(self.mid_term) > 50:
            self.long_term.append(self.mid_term.pop(0))

    def retrieve(self):
        return self.long_term + self.mid_term + self.short_term
