# Simplified Adaptive Conditional Path (ACP)
def predict_complexity(prompt_features):
    # Example heuristic predictor
    length = prompt_features.get("length", 0)
    entropy = prompt_features.get("entropy", 0.0)
    if length < 10 and entropy < 0.5:
        return 0  # simple
    elif length < 50:
        return 1  # moderate
    else:
        return 2  # complex

def get_active_config(complexity_class):
    configs = {
        0: "Use shallow model with 4 layers",
        1: "Use medium-depth model with 8 layers",
        2: "Use full-depth model with all experts"
    }
    return configs.get(complexity_class, "Default")
